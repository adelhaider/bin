GWLST
=====

Groovy WebLogic Scripting Tool

Please see [Wiki](https://github.com/middlewareman/GWLST/wiki) for more information.
